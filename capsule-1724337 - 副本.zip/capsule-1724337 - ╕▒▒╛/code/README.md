# Filter GPS Trajectory Data

- Using Douglas Pucker (DP)
- Using Fuzzy + DP + Resizable Sliding Window 
- Using Fuzzy + DP + Fixed Sliding Window
- Using DP + Resizable Sliding Window 
- Using DP + Fixed Sliding Windo 
