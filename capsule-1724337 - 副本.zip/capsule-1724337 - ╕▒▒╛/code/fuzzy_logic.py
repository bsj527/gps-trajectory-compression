from constants import EPSILON, SAME_SEGMENT_STATUS, FUZZY_RECORD_STATUS, NEW_SEGMENT_STATUS
import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl
from point import Point
import math

# 初始化边界
HEADING_BOUNDARIES = [0, 6e1 * EPSILON, 10, 181]
ACCELERATION_BOUNDARIES = [0, 6e1 * EPSILON, 1, 1000]
DISTANCE_BOUNDARIES = [0, 6e1 * EPSILON, 1, 1000]
SEGMENT_STATE = None


def resetFuzzyMemberships(heading, acceleration, distance):
    global HEADING_BOUNDARIES, ACCELERATION_BOUNDARIES, DISTANCE_BOUNDARIES
    HEADING_BOUNDARIES = heading.copy()
    ACCELERATION_BOUNDARIES = acceleration.copy()
    DISTANCE_BOUNDARIES = distance.copy()
    global SEGMENT_STATE
    SEGMENT_STATE = None


def getHeadingBoundaries():
    return HEADING_BOUNDARIES


def getAccelerationBoundaries():
    return ACCELERATION_BOUNDARIES


def setHeadingBoundaries(increase=True):
    global HEADING_BOUNDARIES, ACCELERATION_BOUNDARIES, DISTANCE_BOUNDARIES
    delta = 5e-3
    factor = (1 + delta) if increase else (1 - delta)

    HEADING_BOUNDARIES[1] = min(max(HEADING_BOUNDARIES[1] * factor, 1e-6), 50)
    ACCELERATION_BOUNDARIES[1] = min(max(ACCELERATION_BOUNDARIES[1] * factor, 1e-6), 1)
    DISTANCE_BOUNDARIES[1] = min(max(DISTANCE_BOUNDARIES[1] * factor, 1e-6), 1)

    HEADING_BOUNDARIES[2] = HEADING_BOUNDARIES[1] * 3
    ACCELERATION_BOUNDARIES[2] = ACCELERATION_BOUNDARIES[1] * 3
    DISTANCE_BOUNDARIES[2] = DISTANCE_BOUNDARIES[1] * 3

    global SEGMENT_STATE
    SEGMENT_STATE = None


def convertGPSToXY(point: Point):
    return [point.latitude, point.longitude]


def estimateNewPosition(point: Point, target_time: float):
    x, y = convertGPSToXY(point)
    delta_time = target_time - point.timestamp
    if delta_time <= 0:
        return [x, y]

    distance = delta_time * point.speed
    angle_rad = math.radians(90 - point.heading)
    delta_x = math.cos(angle_rad) * distance
    delta_y = math.sin(angle_rad) * distance
    return [x + delta_x, y + delta_y]


def _compute_fuzzy_state(delta_heading: float, delta_acceleration: float):
    global SEGMENT_STATE
    if SEGMENT_STATE is None:
        heading = ctrl.Antecedent(np.arange(0, 180, 0.01), 'heading')
        acceleration = ctrl.Antecedent(np.arange(0, 1000, 0.1), 'acceleration')
        segment = ctrl.Consequent(np.arange(0, 1, 0.001), 'segment')

        head_anchor = getHeadingBoundaries()[1]
        acc_anchor = getAccelerationBoundaries()[1]
        c1, c2, c3 = 2, 2, 3

        # === 安全定义 heading ===
        head_same_right = head_anchor * c1
        head_fuzzy_left = max(head_anchor / c2, 1e-6)
        head_fuzzy_right = head_anchor * c3

        heading['same_segment'] = fuzz.trapmf(heading.universe, sorted([0, 0, head_anchor, head_same_right]))
        heading['fuzzy'] = fuzz.trapmf(heading.universe, sorted([head_fuzzy_left, head_anchor, head_fuzzy_right, 180]))
        heading['new_segment'] = fuzz.trapmf(heading.universe, sorted([head_fuzzy_right, 180, 180, 180]))

        # === 安全定义 acceleration ===
        acc_same_right = acc_anchor * c1
        acc_fuzzy_left = max(acc_anchor / c2, 1e-6)
        acc_fuzzy_right = acc_anchor * c3

        acceleration['same_segment'] = fuzz.trapmf(acceleration.universe, sorted([0, 0, acc_anchor, acc_same_right]))
        acceleration['fuzzy'] = fuzz.trapmf(acceleration.universe, sorted([acc_fuzzy_left, acc_anchor, acc_fuzzy_right, 1000]))
        acceleration['new_segment'] = fuzz.trapmf(acceleration.universe, sorted([acc_fuzzy_right, 1000, 1000, 1000]))

        # === 输出和规则 ===
        segment['low'] = fuzz.trimf(segment.universe, [0, 0, 0.02])
        segment['medium'] = fuzz.trimf(segment.universe, [0.01, 0.05, 0.1])
        segment['high'] = fuzz.trimf(segment.universe, [0.08, 1, 1])

        rule1 = ctrl.Rule(heading['new_segment'] | acceleration['new_segment'], segment['high'])
        rule2 = ctrl.Rule(heading['fuzzy'] | acceleration['fuzzy'], segment['medium'])
        rule3 = ctrl.Rule(heading['same_segment'] & acceleration['same_segment'], segment['low'])

        segment_ctrl = ctrl.ControlSystem([rule1, rule2, rule3])
        SEGMENT_STATE = ctrl.ControlSystemSimulation(segment_ctrl)

    SEGMENT_STATE.input['heading'] = delta_heading
    SEGMENT_STATE.input['acceleration'] = delta_acceleration

    try:
        SEGMENT_STATE.compute()
        state_value = SEGMENT_STATE.output['segment']
    except Exception:
        state_value = 0.0

    if state_value >= 0.08:
        return NEW_SEGMENT_STATUS
    elif state_value >= 0.02:
        return FUZZY_RECORD_STATUS
    else:
        return SAME_SEGMENT_STATUS


def getFuzzyState(current: Point, previous: Point, pre_previous: Point, current_point, fuzzy=False, full_fuzzy=False):
    if not fuzzy:
        return SAME_SEGMENT_STATUS
    return getFuzzyMembership(current, previous, pre_previous, current_point)


def getFuzzyMembership(current: Point, previous: Point, pre_previous: Point, current_point):
    if pre_previous is not None:
        delta_head_pp = abs(previous.heading - pre_previous.heading)
        delta_acc_pp = abs(previous.acceleration - pre_previous.acceleration)
        pre_previous_state = _compute_fuzzy_state(delta_head_pp, delta_acc_pp)
    else:
        pre_previous_state = SAME_SEGMENT_STATUS

    delta_head_p = abs(current.heading - previous.heading)
    delta_acc_p = abs(current.acceleration - previous.acceleration)
    previous_state = _compute_fuzzy_state(delta_head_p, delta_acc_p)

    if previous_state == NEW_SEGMENT_STATUS:
        return NEW_SEGMENT_STATUS
    elif previous_state == FUZZY_RECORD_STATUS or pre_previous_state == FUZZY_RECORD_STATUS:
        return FUZZY_RECORD_STATUS
    else:
        return SAME_SEGMENT_STATUS